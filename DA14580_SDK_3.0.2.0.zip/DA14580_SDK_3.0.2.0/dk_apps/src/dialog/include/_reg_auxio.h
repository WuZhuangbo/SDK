#ifndef __REG_AUXIO_H_
#define __REG_AUXIO_H_

#define REG_AUXIO_SIZE 32

#define REG_AUXIO_BASE_ADDR 0x1000A000


#endif // __REG_AUXIO_H_

