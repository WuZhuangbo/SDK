#ifndef __REG_BLECORE_H_
#define __REG_BLECORE_H_

#define REG_BLECORE_SIZE 276

#define REG_BLECORE_BASE_ADDR 0x40000000


#endif // __REG_BLECORE_H_

