#ifndef __REG_CLKRST_H_
#define __REG_CLKRST_H_

#define REG_CLKRST_SIZE 26

//#define REG_CLKRST_BASE_ADDR 0x10000000


#endif // __REG_CLKRST_H_

