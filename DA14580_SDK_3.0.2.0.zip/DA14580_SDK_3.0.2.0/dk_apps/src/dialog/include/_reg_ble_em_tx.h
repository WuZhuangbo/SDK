#ifndef __REG_BLE_EM_TX_H_
#define __REG_BLE_EM_TX_H_

#define REG_BLE_EM_TX_SIZE 42

#define REG_BLE_EM_TX_BASE_ADDR 0x80000


#endif // __REG_BLE_EM_TX_H_

