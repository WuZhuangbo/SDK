#ifndef __REG_EMI1_H_
#define __REG_EMI1_H_

#define REG_EMI1_SIZE 16

//#define REG_EMI1_BASE_ADDR 0x1000C000


#endif // __REG_EMI1_H_

