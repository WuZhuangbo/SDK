#ifndef __REG_REMAP_H_
#define __REG_REMAP_H_

#define REG_REMAP_SIZE 70

//#define REG_REMAP_BASE_ADDR 0x10002000


#endif // __REG_REMAP_H_

