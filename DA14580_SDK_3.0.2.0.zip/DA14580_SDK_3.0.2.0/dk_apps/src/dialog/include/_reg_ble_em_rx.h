#ifndef __REG_BLE_EM_RX_H_
#define __REG_BLE_EM_RX_H_

#define REG_BLE_EM_RX_SIZE 46

#define REG_BLE_EM_RX_BASE_ADDR 0x80000


#endif // __REG_BLE_EM_RX_H_

