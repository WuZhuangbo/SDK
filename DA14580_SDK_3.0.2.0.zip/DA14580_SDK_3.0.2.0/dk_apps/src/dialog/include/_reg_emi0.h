#ifndef __REG_EMI0_H_
#define __REG_EMI0_H_

#define REG_EMI0_SIZE 16

//#define REG_EMI0_BASE_ADDR 0x1000B000


#endif // __REG_EMI0_H_

