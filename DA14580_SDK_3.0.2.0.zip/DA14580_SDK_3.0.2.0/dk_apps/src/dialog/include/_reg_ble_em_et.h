#ifndef __REG_BLE_EM_ET_H_
#define __REG_BLE_EM_ET_H_

#define REG_BLE_EM_ET_SIZE 2

#define REG_BLE_EM_ET_BASE_ADDR 0x80000


#endif // __REG_BLE_EM_ET_H_

