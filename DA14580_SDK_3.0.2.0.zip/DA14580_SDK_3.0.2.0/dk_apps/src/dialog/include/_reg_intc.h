#ifndef __REG_INTC_H_
#define __REG_INTC_H_

#define REG_INTC_SIZE 280

//#define REG_INTC_BASE_ADDR 0x10001000


#endif // __REG_INTC_H_

