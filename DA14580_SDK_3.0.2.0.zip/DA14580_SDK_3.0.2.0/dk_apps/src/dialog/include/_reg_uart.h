#ifndef __REG_UART_H_
#define __REG_UART_H_

//next lines commented by WIK, they are not used
//#define REG_UART_SIZE 56
//#define REG_UART_BASE_ADDR 0x10007000


#endif // __REG_UART_H_

